</div>
<footer class="footer">
    <div class="container_footer">
        <p class="text-muted_footer">This web site develop by <a href="?page=product-all" target="_blank">itemnoob</a></p>
    </div>
</footer>
        <script type="text/javascript" src="<?=$config['site_url']?>/js/bootstrap.min.js"></script>
        <script type="text/javascript" src='<?=$config['site_url']?>/js/jquery.datetimepicker.js'></script>
        <script type="text/javascript" src="<?=$config['site_url']?>/js/djdai.js"></script>
    </body>
</html>