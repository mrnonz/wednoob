﻿    <script type="text/javascript">
        function tmnTopup()
        {
            $("#refilltruemoney_btn").hide();
        }
    </script>
    <?
        if(isset($_POST['refilltruemoney_btn'])){
            $grecaptcha = $_POST['g-recaptcha-response'];
            if(empty($grecaptcha)){
                echo "<div class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> กรุณาติ๊ก Captcha เพื่อยืนยันตัวตน</div>";
                echo "<meta http-equiv='refresh' content='0 ;url=./member.php?page=refill&way=truemoney'>";
                exit();
            }
            $url = 'https://www.google.com/recaptcha/api/siteverify?secret= 6Ld-yF4UAAAAADB7fDL62oD5QUiRCsdlYZ515REY&response='.$grecaptcha.'&ipremote='.$_SERVER['REMOTE_ADDR'];
            $responseURL = json_decode(file_get_contents($url),TRUE);

            if(!is_numeric($_POST['tmn_password']))
            {
                echo "<div class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> กรุณากรอกเฉพาะตัวเลข </div>";
                echo "<meta http-equiv='refresh' content='0 ;url=./member.php?page=refill&way=truemoney'>";
                exit();
            }

            if(strlen($_POST['tmn_password']) != 14)
            {
                echo "<div class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> กรุณากรอกรหัสบัตรทรูมันนี่ให้ถูกต้อง </div>";
                echo "<meta http-equiv='refresh' content='0 ;url=./member.php?page=refill&way=truemoney'>";
                exit();
            }

            if($responseURL['success'] = '1')
            {
                    
            }
            else
            {   
                echo "<div class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> คุณเป็นบอท !</div>";
                echo "<meta http-equiv='refresh' content='0 ;url=./member.php?page=refill&way=truemoney'>";
                exit();
            }

            $sql_tmpw_failed = 'SELECT * FROM truemoney_failed WHERE truemoney_password = "'.$_POST['tmn_password'].'" LIMIT 1';
            $query_tmpw_failed = $connect->query($sql_tmpw_failed);
            $fetch_tmpw_failed = $query_tmpw_failed->fetch_assoc();
            $numrow_tmpw_failed = $query_tmpw_failed->num_rows;

            if($numrow_tmpw_failed == 1)
            {
                echo "<div class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> เกิดข้อผิดพลาด </div>";
                echo "<meta http-equiv='refresh' content='0 ;url=./member.php?page=refill&way=truemoney'>";
                exit();
            }

            $sql_truewallet_user = 'SELECT * FROM truewallet_user ORDER BY RAND() LIMIT 1';
            $query_truewallet_user = $connect->query($sql_truewallet_user);
            $fetch_truewallet_user = $query_truewallet_user->fetch_assoc();

            @ob_start();
            @$tw = $_POST['tmn_password'];
            @$user = $fetch_truewallet_user['email'];
            @$pass = $fetch_truewallet_user['password'];

            include ('class.truewallet.php');
            $wallet = new TrueWallet(($user),($pass),'email');
            $token = json_decode($wallet->GetToken(),true)['data']['accessToken'];
            //
            $objtw = json_decode($wallet->Topup($tw,$token));

            @$objjb = $objtw->titleTh;
            if($objtw->amount > 49)
            {
                $fee_balance_one = $objtw->amount * 15;
                $fee_balance_two = $fee_balance_one / 100;
                $fee_balance_use = $objtw->amount - $fee_balance_two;
                $sql_update_point = 'UPDATE member SET credit = credit+"'.$fee_balance_use.'" WHERE uid = "'.$_SESSION["member_uid"].'"';
                $query_update_user = $connect->query($sql_update_point);
                if($query_update_user)
                {
                    $topup_datetime = date('d/m/Y H:i');
                    $sql_topup_insert = 'INSERT INTO refill (refill_uid,refill_username,refill_type,refill_datetime,refill_credit,refill_detail,refill_status,refill_code,refill_rdmUser) VALUES ("'.$_POST['ref2'].'","'.$_POST['ref1'].'","Truemoney","'.$topup_datetime.'","'.$fee_balance_use.'","'.$tw.'","1","'.$objtw->code.'","'.$fetch_truewallet_user['email'].'")';
                    $query_topup_insert = $connect->query($sql_topup_insert);
                    if($query_update_user)
                    {
                        echo "<div id='trueerror' class='alert alert-success'>";
                        echo "<span class='glyphicon glyphicon-info-sign'></span> เติมเงินเรียบร้อยแล้ว</div>";
                        echo "<meta http-equiv='refresh' content='2 ;url=./member.php?page=refill&way=truemoney'>";
                        //print_r($objtw);
                    }
                }
            }
            else
            {
                $topup_datetime = date('d/m/Y H:i');
                $sql_topup_insert = 'INSERT INTO refill (refill_uid,refill_username,refill_type,refill_datetime,refill_credit,refill_detail,refill_status,refill_code,refill_rdmUser) VALUES ("'.$_POST['ref2'].'","'.$_POST['ref1'].'","Truemoney","'.$topup_datetime.'","'.$fee_balance_use.'","'.$tw.'","2","'.$objtw->code.'","'.$fetch_truewallet_user['email'].'")';
                $query_topup_insert = $connect->query($sql_topup_insert);

                //ถ้ารหัสบัตรผิด (CODE = -1002)
                if($objtw->code == "-1002")
                {
                    $sql_insert_failed = 'INSERT INTO truemoney_failed (uid,username,truemoney_password) VALUES ("'.$_POST['ref2'].'","'.$_POST['ref1'].'","'.$tw.'")';
                    $query_insert_failed = $connect->query($sql_insert_failed);
                }

                echo "<div id='trueerror' class='alert alert-danger'>";
                echo "<span class='glyphicon glyphicon-info-sign'></span> เกิดข้อผิดพลาด หรือ รหัสบัตรทรูมันนี่นี้ใช้ไม่ได้</div>";
                echo "<meta http-equiv='refresh' content='2 ;url=./member.php?page=refill&way=truemoney'>";
                //print_r($objtw);
                //print_r($token);
            }
        }
    ?>
    <div class="text-center">
        <h3></h3>
        <div class="alert alert-warning" role="alert"><strong>คำเตือน!</strong> การเติมเงินด้วยบัตรเงินสดทรูมันนี่ มีค่าธรรมเนียม 15% ตามตารางข้างล่าง <br/>
        ระบบจะตรวจสอบบัตรเงินสดอัตโนมัติ และเงินจะเข้าระบบทันทีหลังทำรายการสำเร็จ</div>
        <h4>กรอกข้อมูลบัตรทรูมันนี่</h4>
    <form name="tmn_form" method="POST">
        <div class="form-horizontal">
            <div class="form-group">
                <label class="col-sm-4 control-label" for="ref1">Username : </label>
                <div class="col-sm-6">
                    <input type="text" name="ref1" id="ref1" class="form-control" value="<?php echo $user_name; ?>" readonly=""/>
                </div>
            </div>
            <input type="hidden" name="ref2" id="ref2" class="form-control" value="<?php echo $member['uid']; ?>"/>
            <input type="hidden" name="ref3" id="ref3" class="form-control" value="<?php echo $member['email']; ?>"/>
            <div class="form-group">
                <label class="col-sm-4 control-label" for="tmn_password">บัตรทรูมันนี่ : </label>
                <div class="col-sm-6">
                    <input type="text" name="tmn_password" id="tmn_password" class="form-control" required="" autocomplete="off" maxlength="14" onkeypress="return NumbersOnly(event);" placeholder="รหัสบัตรทรูมันนี่ 14 หลัก"/>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-10">
                    <center>
                        <div class="g-recaptcha" data-sitekey="6Ld-yF4UAAAAAIrdnbnFJoVRRiEOEK201TrhjYpU"></div>
                    </center>
                </div>
            </div>
            <p><input type="submit" name="refilltruemoney_btn" id="refilltruemoney_btn" class="btn btn-primary" value="เติมเงินด้วยบัตรทรูมันนี่" onclick="tmnTopup()" /></p>
        </div>
    </form>
    </div>

    <div class="text-center">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">ราคาบัตรทรูมันนี่</th>
                        <th class="text-center">ยอดเงินที่ได้รับ</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>50 Truemoney</td>
                        <td>42.50 บาท</td>
                    </tr>
                    <tr>
                        <td>90 Truemoney</td>
                        <td>76.50 บาท</td>
                    </tr>
                    <tr>
                        <td>150 Truemoney</td>
                        <td>127.50 บาท</td>
                    </tr>
                    <tr>
                        <td>300 Truemoney</td>
                        <td>255.00 บาท</td>
                    </tr>
                    <tr>
                        <td>500 Truemoney</td>
                        <td>425.00 บาท</td>
                    </tr>
                    <tr>
                        <td>1000 Truemoney</td>
                        <td>850.00 บาท</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>