﻿<script type="text/javascript">
    function DontClick(){
        $("#refilltruewallet_btn").html('<i class="fa fa-spinner fa-spin fa-lg"></i> กำลังแจ้งโอนเงิน');
    }
</script>

<?
    if($webinfo['webinfo_wallettype'] == '1' /*$_SESSION['member_status'] != '5'*/)
    {
        echo "<center><b>ขณะนี้ระบบ TrueWallet ปิดปรับปรุง</b></center>";
    }
    else
    {
        if(isset($_POST['refilltruewallet_btn']))
        {
            include ('class.truewallet.php');
            @$user = "waltalkingjames@outlook.com";
            @$pass = "itemnoobstore90";
            
            //* DAY Setup
            $today_day =  date("d");
            $today_month = date("m");
            $today_year =  date("Y");
            $today_year_s = $today_year - 1;
            $today_use_check_s = $today_year_s."-".$today_month."-".$today_day;
            $today_year_e = $today_year + 1;
            $today_use_check_e = $today_year_e."-".$today_month."-".$today_day;
            //* END DAY Setup

            $wallet = new TrueWallet(($user),($pass),'email'); // LOGIN
            $token = json_decode($wallet->GetToken(),true)['data']['accessToken']; // GET TOKEN
            
            if(empty($_POST['refilltruewallet_transaction']))
            {
                exit();
                header('location: member.php?page=refill&way=truewallet');
            }
            else
            {
                if($getTran = json_decode($wallet->getTran($token,$today_use_check_s,$today_use_check_e)))
                {
                    $Tran = $getTran->data->activities;
                }

                if($Tran[0]&&$Checkreport = json_decode($wallet->CheckTran($token,$Tran[0]->reportID)))
                {
                    $report = $Checkreport->data;
                }

                $tran_type_want = "creditor";
                $fti_u = "0";
                foreach($Tran as $transaction)
                {
                    $tran_type = $transaction->text3En;
                    if($tran_type == $tran_type_want)
                    {
                        $last_report = $transaction->reportID;
                        if($full_last_report = json_decode($wallet->CheckTran($token,$last_report)))
                        {
                            $flr = $full_last_report->data;
                            $fti = $flr->section4->column2->cell1->value;
                            $ftam = $flr->amount;
                            $ftm = $flr->personalMessage->value;
                            $ftphone = $flr->ref1;
                            $ftdate = $flr->section4->column1->cell1->value;
                        }

                        if($fti == $_POST['refilltruewallet_transaction'])
                        {
                            if($ftphone == $_POST['refilltruewallet_number'])
                            {
                                $fti_u = $fti;
                                $ftam_u = $ftam;
                                $ftm_u = $ftm;
                                $ftphone_u = $ftphone;
                                $ftdate_u = $ftdate;
                                break;
                            }
                        }
                    }
                }

                if($fti_u == $_POST['refilltruewallet_transaction'])
                {
                    /*
                    echo "หมายเลขอ้างอิง: ".$fti_u."<br/>";
                    echo "จำนวนเงิน: ".$ftam_u."<br/>";
                    echo "ข้อความ: ".$ftm_u."<br/>";
                    echo $ftphone_u."<br/>";
                    echo $ftdate_u."<br/>";
                    */
                    $query_check_tran = $connect->query('SELECT * FROM refill WHERE refill_tw_id = "'.$fti_u.'" LIMIT 1');
                    $num_tran = $query_check_tran->num_rows;
                    if($num_tran == 1)
                    {
                        exit('<div class="alert alert-danger"><strong>Error: </strong>มีการใช้ Transaction นี้แจ้งเข้ามาในระบบแล้ว</div>');
                    }
                    else
                    {
                        $sql_insert_transaction = 'INSERT INTO refill (refill_uid,refill_username,refill_type,refill_datetime,refill_credit,refill_detail,refill_tw_id,refill_status) VALUES ("'.$_SESSION['member_uid'].'","'.$_SESSION['member_username'].'","True Wallet","'.$ftdate_u.'","'.$ftam_u.'","'.$ftphone_u.'","'.$fti_u.'","1")';
                        $query_insert_transaction = $connect->query($sql_insert_transaction);
                        if($query_insert_transaction)
                        {
                           $sql_update_point = 'UPDATE member SET credit = credit+"'.$ftam_u.'" WHERE uid = "'.$_SESSION['member_uid'].'"';
                           $query_update_point = $connect->query($sql_update_point);
                           if($query_update_point)
                           {
                            echo '<div class="alert alert-success"><strong>SUCCEED: </strong>ยอดเงินได้เพิ่มเข้าบัญชีข้องท่านแล้ว กด F5 เพื่อเช็คจำนวนเงิน<b>'.$ftam_u.'</b> บาท</div>';
                           }
                        }
                    } 
                }
                else
                {
                    exit('<div class="alert alert-danger"><strong>Error: </strong>ไม่พบ Transaction นี้</div>');
                }

            }
        }
?>

<span style="font-size: 20px;">ก่อนแจ้งเติมเงิน โอนเงินมาที่  True Wallet : <u><strong><?php echo $webinfo['webinfo_truewallet']; ?></strong></u></span>

<h4>แจ้งโอนเงิน</h4>
<div class="col-sm-6 col-sm-offset-3">
    <form name="refilltruewallet_frm" id="refilltruewallet_frm" method="POST">
        <input type="hidden" name="refilltruewallet_username" id="refilltruewallet_username" value="<?php echo $member['username']; ?>"/>
        <input type="hidden" name="type_topup" id="type_topup" value="1"/>
        <div class="form-group col-md-12">
            <label class="control-label">เบอร์บัญชีทรูวอตเล็ตของคุณ : </label>
            <input type="text" name="refilltruewallet_number" id="refilltruewallet_number" class="form-control" required="" autocomplete="off" onkeypress="return NumbersOnly(event);" maxlength="10"/>
        </div>
        <div class="form-group col-md-12">
            <label class="control-label">หมายเลขอ้างอิง (ได้หลังจากโอนเงิน ต้องแจ้งภายใน 10 นาที) : </label>
                <input type="text" name="refilltruewallet_transaction" id="refilltruewallet_transaction" class="form-control" required="" autocomplete="off" onkeypress="return NumbersandDot(event);" maxlength="20"/>
        </div>
        <!-- <div class="form-group col-md-12">
            <label class="control-label">Captcha : </label>
            <div class="g-recaptcha" id="refill_recaptcha" data-sitekey="6LeG2yITAAAAAKknoj91Ww0tWFlx6gyoFYBBIvQd"></div>
        </div> -->
        <img src="images/truewallet.jpg" width="100%" style="border-radius: 8px 8px 8px 8px;" alt="วิธีการเติมเงินด้วย TrueWallet"/>
        <div class="col-md-12 text-center">
            <button type="submit" name="refilltruewallet_btn" style="margin-top:5px;" id="refilltruewallet_btn" class="btn btn-primary" onclick="DontClick();">แจ้งเติมเงิน</button>
        </div>
    </form>

</div>
    <?
    }
?>